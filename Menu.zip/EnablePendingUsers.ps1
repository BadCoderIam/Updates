﻿param(
  [string]$PendingPath = 'C:\IntuneTools\PendingActivations.json',
  [string]$Environment = 'USGov'
)
Import-Module Microsoft.Graph.Authentication
Import-Module Microsoft.Graph.Users
try { $ctx = Get-MgContext -ErrorAction Stop } catch { $ctx = $null }
if (-not $ctx -or -not $ctx.Account) {
  Connect-MgGraph -Environment $Environment -Scopes 'User.ReadWrite.All' -NoWelcome | Out-Null
}
if (-not (Test-Path $PendingPath)) { return }
try { $items = Get-Content -Path $PendingPath -Raw | ConvertFrom-Json } catch { return }
if (-not $items) { return }
$now = [DateTime]::UtcNow
$rem = @()
foreach ($it in $items) {
  try {
    if ([DateTime]::Parse($it.startUtc) -le $now) { Update-MgUser -UserId $it.userId -AccountEnabled $true | Out-Null }
    else { $rem += $it }
  } catch { $rem += $it }
}
($rem | ConvertTo-Json) | Set-Content -Path $PendingPath -Encoding UTF8
